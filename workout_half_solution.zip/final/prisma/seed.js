import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

function daysAgo(days) {
  const date = new Date();
  date.setDate(date.getDate() - days);
  return date;
}

async function main() {
  await prisma.set.deleteMany();
  await prisma.workout.deleteMany();

  await prisma.workout.create({
    data: {
      name: "Morning Run",
      discipline: "Cardio",
      targetMinutes: 30,
      sets: {
        create: [
          { exercise: "Easy run", reps: 10, weight: null, completedAt: daysAgo(1) },
          { exercise: "Intervals", reps: 8, weight: null, completedAt: daysAgo(4) },
          { exercise: "Hill run", reps: 7, weight: null, completedAt: daysAgo(8) },
          { exercise: "Recovery jog", reps: 6, weight: null, completedAt: daysAgo(12) }
        ]
      }
    }
  });

  await prisma.workout.create({
    data: {
      name: "Upper Body Strength",
      discipline: "Strength",
      targetMinutes: 40,
      sets: {
        create: [
          { exercise: "Bench press", reps: 10, weight: 60, completedAt: daysAgo(2) },
          { exercise: "Row", reps: 12, weight: 45, completedAt: daysAgo(5) },
          { exercise: "Shoulder press", reps: 8, weight: 30, completedAt: daysAgo(9) },
          { exercise: "Biceps curl", reps: 12, weight: 15, completedAt: daysAgo(13) }
        ]
      }
    }
  });

  await prisma.workout.create({
    data: {
      name: "Mobility Flow",
      discipline: "Mobility",
      targetMinutes: 20,
      sets: {
        create: [
          { exercise: "Hip stretch", reps: 5, weight: null, completedAt: daysAgo(3) },
          { exercise: "Shoulder circles", reps: 10, weight: null, completedAt: daysAgo(6) },
          { exercise: "Hamstring stretch", reps: 6, weight: null, completedAt: daysAgo(10) },
          { exercise: "Back rotation", reps: 8, weight: null, completedAt: daysAgo(14) }
        ]
      }
    }
  });
}

main()
  .then(async () => {
    await prisma.$disconnect();
  })
  .catch(async (error) => {
    console.error(error);
    await prisma.$disconnect();
    process.exit(1);
  });

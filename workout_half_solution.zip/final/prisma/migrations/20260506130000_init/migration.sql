CREATE TABLE "Workout" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "name" TEXT NOT NULL,
    "discipline" TEXT NOT NULL,
    "targetMinutes" INTEGER NOT NULL
);

CREATE TABLE "Set" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "exercise" TEXT NOT NULL,
    "reps" INTEGER NOT NULL,
    "weight" REAL,
    "completedAt" DATETIME NOT NULL,
    "workoutId" TEXT NOT NULL,
    CONSTRAINT "Set_workoutId_fkey" FOREIGN KEY ("workoutId") REFERENCES "Workout" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE UNIQUE INDEX "Workout_name_key" ON "Workout"("name");

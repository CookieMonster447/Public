import { prisma } from "../lib/prisma.js";

function getCompletedAtWhere(from, to) {
  const completedAt = {};

  if (from) {
    completedAt.gte = new Date(`${from}T00:00:00.000`);
  }

  if (to) {
    completedAt.lte = new Date(`${to}T23:59:59.999`);
  }

  if (Object.keys(completedAt).length === 0) {
    return undefined;
  }

  return completedAt;
}

export async function getWorkouts(from, to) {
  const completedAt = getCompletedAtWhere(from, to);

  return await prisma.workout.findMany({
    orderBy: {
      name: "asc"
    },
    include: {
      sets: {
        where: completedAt ? { completedAt } : undefined,
        orderBy: {
          completedAt: "desc"
        }
      }
    }
  });
}

export async function getStats(from, to) {
  const completedAt = getCompletedAtWhere(from, to);

  const workouts = await prisma.workout.findMany({
    select: {
      id: true,
      discipline: true
    }
  });

  const grouped = await prisma.set.groupBy({
    by: ["workoutId"],
    where: completedAt ? { completedAt } : {},
    _count: {
      id: true
    },
    _sum: {
      reps: true,
      weight: true
    }
  });

  const workoutDisciplines = new Map();
  const stats = {};

  for (const workout of workouts) {
    workoutDisciplines.set(workout.id, workout.discipline);
    stats[workout.discipline] = {
      discipline: workout.discipline,
      totalSets: 0,
      totalReps: 0,
      averageReps: 0,
      totalWeight: 0
    };
  }

  for (const row of grouped) {
    const discipline = workoutDisciplines.get(row.workoutId);

    if (!discipline) {
      continue;
    }

    stats[discipline].totalSets += row._count.id;
    stats[discipline].totalReps += row._sum.reps || 0;
    stats[discipline].totalWeight += row._sum.weight || 0;
  }

  return Object.values(stats).map((row) => ({
    discipline: row.discipline,
    totalSets: row.totalSets,
    averageReps: row.totalSets === 0 ? "0.0" : (row.totalReps / row.totalSets).toFixed(1),
    totalWeight: row.totalWeight
  }));
}

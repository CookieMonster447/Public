import { headers } from "next/headers";
import { getStats } from "../repos/workoutRepository.js";

async function getBaseUrl() {
  const headerList = await headers();
  const host = headerList.get("host") || "localhost:3000";
  const protocol = host.includes("localhost") || host.includes("127.0.0.1") ? "http" : "https";

  return `${protocol}://${host}`;
}

async function getWorkoutsFromApi(from, to) {
  const baseUrl = await getBaseUrl();
  const url = new URL(`${baseUrl}/api/workouts`);

  if (from) {
    url.searchParams.set("from", from);
  }

  if (to) {
    url.searchParams.set("to", to);
  }

  const response = await fetch(url, {
    cache: "no-store"
  });

  if (!response.ok) {
    return [];
  }

  return await response.json();
}

function formatDate(value) {
  return new Date(value).toLocaleDateString("en-CA");
}

function getTotalReps(sets) {
  return sets.reduce((total, set) => total + set.reps, 0);
}

export default async function Page({ searchParams }) {
  const params = await searchParams;
  const from = params?.from || "";
  const to = params?.to || "";
  const workouts = await getWorkoutsFromApi(from, to);
  const stats = await getStats(from, to);

  return (
    <main className="page">
      <h1>Workout Log</h1>

      <section className="card">
        <h2>Stats</h2>
        <table>
          <thead>
            <tr>
              <th>Discipline</th>
              <th>Total sets</th>
              <th>Average reps</th>
              <th>Total weight</th>
            </tr>
          </thead>
          <tbody>
            {stats.map((row) => (
              <tr key={row.discipline}>
                <td>{row.discipline}</td>
                <td>{row.totalSets}</td>
                <td>{row.averageReps}</td>
                <td>{row.totalWeight}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>

      <section className="card">
        <h2>Filter</h2>
        <form method="GET" className="filters">
          <label>
            From
            <input type="date" name="from" defaultValue={from} />
          </label>
          <label>
            To
            <input type="date" name="to" defaultValue={to} />
          </label>
          <button type="submit">Apply</button>
        </form>
      </section>

      <section className="workouts">
        {workouts.map((workout) => {
          const totalReps = getTotalReps(workout.sets);
          const met = totalReps >= workout.targetMinutes;

          return (
            <article key={workout.id} className={`workout ${met ? "met" : "muted"}`}>
              <div className="workoutHeader">
                <div>
                  <h2>{workout.name}</h2>
                  <p>{workout.discipline}</p>
                </div>
                <div className="target">
                  <span>Target {workout.targetMinutes}</span>
                  <strong>{met ? "met" : "muted"}</strong>
                </div>
              </div>

              <p>Total reps shown: {totalReps}</p>

              {workout.sets.length === 0 ? (
                <p>No sets in this range.</p>
              ) : (
                <table>
                  <thead>
                    <tr>
                      <th>Exercise</th>
                      <th>Reps</th>
                      <th>Weight</th>
                      <th>Completed</th>
                    </tr>
                  </thead>
                  <tbody>
                    {workout.sets.map((set) => (
                      <tr key={set.id}>
                        <td>{set.exercise}</td>
                        <td>{set.reps}</td>
                        <td>{set.weight ?? "-"}</td>
                        <td>{formatDate(set.completedAt)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </article>
          );
        })}
      </section>
    </main>
  );
}

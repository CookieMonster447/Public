import { getWorkouts } from "../../../repos/workoutRepository.js";

export async function GET(request) {
  const url = new URL(request.url);
  const from = url.searchParams.get("from") || "";
  const to = url.searchParams.get("to") || "";
  const workouts = await getWorkouts(from, to);

  return Response.json(workouts);
}

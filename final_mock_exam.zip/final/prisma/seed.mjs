import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

const daysAgo = (days) => {
  const date = new Date();
  date.setDate(date.getDate() - days);
  return date;
};

async function main() {
  await prisma.set.deleteMany();
  await prisma.workout.deleteMany();

  const workouts = [
    {
      name: "Morning Run",
      discipline: "Cardio",
      targetMinutes: 30,
      sets: [
        { exercise: "Jogging", reps: 1, weight: null, minutes: 10, completedAt: daysAgo(1) },
        { exercise: "Intervals", reps: 6, weight: null, minutes: 12, completedAt: daysAgo(4) },
        { exercise: "Incline Walk", reps: 1, weight: null, minutes: 8, completedAt: daysAgo(8) },
        { exercise: "Cycling", reps: 1, weight: null, minutes: 15, completedAt: daysAgo(13) }
      ]
    },
    {
      name: "Push Day",
      discipline: "Strength",
      targetMinutes: 45,
      sets: [
        { exercise: "Bench Press", reps: 8, weight: 70, minutes: 12, completedAt: daysAgo(2) },
        { exercise: "Shoulder Press", reps: 10, weight: 32.5, minutes: 10, completedAt: daysAgo(5) },
        { exercise: "Triceps Pushdown", reps: 12, weight: 25, minutes: 8, completedAt: daysAgo(9) },
        { exercise: "Incline Dumbbell Press", reps: 10, weight: 40, minutes: 15, completedAt: daysAgo(14) }
      ]
    },
    {
      name: "Stretch Session",
      discipline: "Mobility",
      targetMinutes: 20,
      sets: [
        { exercise: "Hamstring Stretch", reps: 3, weight: null, minutes: 5, completedAt: daysAgo(3) },
        { exercise: "Hip Openers", reps: 3, weight: null, minutes: 6, completedAt: daysAgo(6) },
        { exercise: "Thoracic Rotation", reps: 3, weight: null, minutes: 4, completedAt: daysAgo(10) },
        { exercise: "Ankle Mobility", reps: 3, weight: null, minutes: 5, completedAt: daysAgo(12) }
      ]
    }
  ];

  for (const workout of workouts) {
    await prisma.workout.create({
      data: {
        name: workout.name,
        discipline: workout.discipline,
        targetMinutes: workout.targetMinutes,
        sets: {
          create: workout.sets.map((set) => ({
            ...set,
            discipline: workout.discipline
          }))
        }
      }
    });
  }
}

main()
  .finally(async () => {
    await prisma.$disconnect();
  });

Put application screenshots in this folder before submitting.

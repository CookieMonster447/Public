import { prisma } from "@/lib/prisma";

function getDateWhere(from, to) {
  const where = {};

  if (from || to) {
    where.completedAt = {};
    if (from) where.completedAt.gte = new Date(`${from}T00:00:00`);
    if (to) where.completedAt.lte = new Date(`${to}T23:59:59`);
  }

  return where;
}

export async function readWorkouts({ from, to } = {}) {
  return await prisma.workout.findMany({
    orderBy: {
      name: "asc"
    },
    include: {
      sets: {
        where: getDateWhere(from, to),
        orderBy: {
          completedAt: "desc"
        }
      }
    }
  });
}

export async function createWorkout(data) {
  const name = data.name?.trim();
  const discipline = data.discipline;
  const targetMinutes = Number(data.targetMinutes);

  if (!name) {
    throw new Error("Workout name is required");
  }

  if (!["Cardio", "Strength", "Mobility"].includes(discipline)) {
    throw new Error("Invalid discipline");
  }

  if (!Number.isInteger(targetMinutes) || targetMinutes <= 0) {
    throw new Error("Target minutes must be a positive integer");
  }

  return await prisma.workout.create({
    data: {
      name,
      discipline,
      targetMinutes
    }
  });
}

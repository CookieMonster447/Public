import { prisma } from "@/lib/prisma";

function getDateWhere(from, to) {
  const where = {};

  if (from || to) {
    where.completedAt = {};
    if (from) where.completedAt.gte = new Date(`${from}T00:00:00`);
    if (to) where.completedAt.lte = new Date(`${to}T23:59:59`);
  }

  return where;
}

export async function readSets(workoutId) {
  return await prisma.set.findMany({
    where: {
      workoutId
    },
    orderBy: {
      completedAt: "desc"
    }
  });
}

export async function createSet(data) {
  const workoutId = data.workoutId;
  const exercise = data.exercise?.trim();
  const reps = Number(data.reps);
  const minutes = Number(data.minutes);
  const weight =
    data.weight === undefined || data.weight === null || data.weight === ""
      ? null
      : Number(data.weight);
  const completedAt = new Date(data.completedAt);

  const workout = await prisma.workout.findUnique({
    where: {
      id: workoutId
    }
  });

  if (!workout) {
    throw new Error("Workout not found");
  }

  if (!exercise) {
    throw new Error("Exercise is required");
  }

  if (!Number.isInteger(reps) || reps <= 0) {
    throw new Error("Reps must be a positive integer");
  }

  if (!Number.isInteger(minutes) || minutes <= 0) {
    throw new Error("Minutes must be a positive integer");
  }

  if (Number.isNaN(completedAt.getTime())) {
    throw new Error("Completed date is required");
  }

  if (completedAt > new Date()) {
    throw new Error("Completed date cannot be in the future");
  }

  if (workout.discipline === "Strength" && weight === null) {
    throw new Error("Strength sets require weight");
  }

  if (weight !== null && Number.isNaN(weight)) {
    throw new Error("Weight must be a number");
  }

  return await prisma.set.create({
    data: {
      workoutId,
      exercise,
      reps,
      minutes,
      weight,
      discipline: workout.discipline,
      completedAt
    }
  });
}

export async function updateSet(id, data) {
  const current = await prisma.set.findUnique({
    where: {
      id
    },
    include: {
      workout: true
    }
  });

  if (!current) {
    throw new Error("Set not found");
  }

  const reps = Number(data.reps);
  const weight =
    data.weight === undefined || data.weight === null || data.weight === ""
      ? null
      : Number(data.weight);

  if (!Number.isInteger(reps) || reps <= 0) {
    throw new Error("Reps must be a positive integer");
  }

  if (current.workout.discipline === "Strength" && weight === null) {
    throw new Error("Strength sets require weight");
  }

  if (weight !== null && Number.isNaN(weight)) {
    throw new Error("Weight must be a number");
  }

  return await prisma.set.update({
    where: {
      id
    },
    data: {
      reps,
      weight
    }
  });
}

export async function deleteSet(id) {
  return await prisma.set.delete({
    where: {
      id
    }
  });
}

export async function readStats({ from, to } = {}) {
  return await prisma.set.groupBy({
    by: ["discipline"],
    where: getDateWhere(from, to),
    _count: {
      id: true
    },
    _avg: {
      reps: true
    },
    _sum: {
      weight: true
    },
    orderBy: {
      discipline: "asc"
    }
  });
}

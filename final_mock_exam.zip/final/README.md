# Final Mock Exam Solution

Run:

```bash
bun install
bunx prisma migrate dev --name init
bunx prisma db seed
bun dev
```

Open:

```txt
http://localhost:3000
```

"use client";

import { useState } from "react";

export default function Set({ set, onSaved, onDeleted }) {
  const [reps, setReps] = useState(String(set.reps));
  const [weight, setWeight] = useState(set.weight === null ? "" : String(set.weight));
  const [initial, setInitial] = useState({
    reps: String(set.reps),
    weight: set.weight === null ? "" : String(set.weight)
  });
  const [error, setError] = useState("");

  const changed = reps !== initial.reps || weight !== initial.weight;

  async function save() {
    setError("");

    const response = await fetch(`/api/sets/${set.id}`, {
      method: "PATCH",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        reps,
        weight
      })
    });

    const data = await response.json();

    if (!response.ok) {
      setError(data.error);
      return;
    }

    setInitial({
      reps: String(data.reps),
      weight: data.weight === null ? "" : String(data.weight)
    });

    setReps(String(data.reps));
    setWeight(data.weight === null ? "" : String(data.weight));
    onSaved(data);
  }

  async function remove() {
    setError("");

    const response = await fetch(`/api/sets/${set.id}`, {
      method: "DELETE"
    });

    const data = await response.json();

    if (!response.ok) {
      setError(data.error);
      return;
    }

    onDeleted(set.id);
  }

  return (
    <div className="set-row">
      <span>{set.exercise}</span>

      <input
        value={reps}
        onChange={(event) => setReps(event.target.value)}
        type="number"
        min="1"
      />

      <input
        value={weight}
        onChange={(event) => setWeight(event.target.value)}
        type="number"
        step="0.1"
        placeholder="Weight"
      />

      <button onClick={save} disabled={!changed}>
        Save
      </button>

      <button onClick={remove}>
        Delete
      </button>

      {error && <p className="error">{error}</p>}
    </div>
  );
}

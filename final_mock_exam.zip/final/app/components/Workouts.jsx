import { headers } from "next/headers";
import { revalidatePath } from "next/cache";
import { createWorkout } from "@/repos/workouts";
import Workout from "./Workout";

async function getWorkouts(from, to) {
  const headerList = await headers();
  const host = headerList.get("host");
  const protocol = process.env.NODE_ENV === "development" ? "http" : "https";
  const params = new URLSearchParams();

  if (from) params.set("from", from);
  if (to) params.set("to", to);

  const response = await fetch(`${protocol}://${host}/api/workouts?${params.toString()}`, {
    cache: "no-store"
  });

  return await response.json();
}

export default async function Workouts({ from, to }) {
  const workouts = await getWorkouts(from, to);

  async function createWorkoutAction(formData) {
    "use server";

    await createWorkout({
      name: formData.get("name"),
      discipline: formData.get("discipline"),
      targetMinutes: formData.get("targetMinutes")
    });

    revalidatePath("/");
  }

  return (
    <section>
      <form action={createWorkoutAction} className="card form">
        <h2>Add Workout</h2>

        <input name="name" placeholder="Workout name" required />

        <select name="discipline" required>
          <option value="Cardio">Cardio</option>
          <option value="Strength">Strength</option>
          <option value="Mobility">Mobility</option>
        </select>

        <input name="targetMinutes" type="number" min="1" placeholder="Target minutes" required />

        <button>Add Workout</button>
      </form>

      <div className="workouts">
        {workouts.map((workout) => (
          <Workout key={workout.id} workout={workout} />
        ))}
      </div>
    </section>
  );
}

"use client";

import { useActionState } from "react";
import { createSetAction } from "../actions";

const initialState = {
  error: "",
  ok: false
};

export default function AddSetForm({ workoutId }) {
  const [state, formAction, pending] = useActionState(createSetAction, initialState);

  return (
    <form action={formAction} className="set-form">
      <input type="hidden" name="workoutId" value={workoutId} />

      <input name="exercise" placeholder="Exercise" required />

      <input name="reps" type="number" min="1" placeholder="Reps" required />

      <input name="minutes" type="number" min="1" placeholder="Minutes" required />

      <input name="weight" type="number" step="0.1" placeholder="Weight" />

      <input name="completedAt" type="datetime-local" required />

      <button disabled={pending}>Add Set</button>

      {state.error && <p className="error">{state.error}</p>}
    </form>
  );
}

"use client";

import { useEffect, useState } from "react";
import Set from "./Set";

export default function Sets({ workoutId }) {
  const [sets, setSets] = useState([]);

  useEffect(() => {
    async function loadSets() {
      const response = await fetch(`/api/workouts/${workoutId}/sets`);
      const data = await response.json();
      setSets(data);
    }

    loadSets();
  }, [workoutId]);

  function replaceSet(updatedSet) {
    setSets((current) =>
      current.map((set) => (set.id === updatedSet.id ? updatedSet : set))
    );
  }

  function removeSet(id) {
    setSets((current) => current.filter((set) => set.id !== id));
  }

  return (
    <section className="edit">
      <h3>Edit Sets</h3>

      {sets.map((set) => (
        <Set
          key={set.id}
          set={set}
          onSaved={replaceSet}
          onDeleted={removeSet}
        />
      ))}
    </section>
  );
}

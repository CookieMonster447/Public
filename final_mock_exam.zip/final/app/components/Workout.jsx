import AddSetForm from "./AddSetForm";
import Sets from "./Sets";

export default function Workout({ workout }) {
  const totalMinutes = workout.sets.reduce((sum, set) => sum + set.minutes, 0);
  const met = totalMinutes >= workout.targetMinutes;

  return (
    <article className={met ? "card workout met" : "card workout muted"}>
      <header>
        <h2>{workout.name}</h2>
        <p>{workout.discipline}</p>
        <p>
          {totalMinutes}/{workout.targetMinutes} minutes
        </p>
      </header>

      <ul>
        {workout.sets.map((set) => (
          <li key={set.id}>
            {set.exercise} — {set.reps} reps — {set.weight ?? 0} kg — {set.minutes} min —{" "}
            {new Date(set.completedAt).toLocaleDateString()}
          </li>
        ))}
      </ul>

      <AddSetForm workoutId={workout.id} />

      <Sets workoutId={workout.id} />
    </article>
  );
}

import { readStats } from "@/repos/sets";
import Workouts from "./components/Workouts";
import "./global.css";

export default async function Page({ searchParams }) {
  const params = await searchParams;
  const from = params.from || "";
  const to = params.to || "";
  const stats = await readStats({ from, to });

  return (
    <main>
      <h1>Workout Log</h1>

      <section className="card">
        <h2>Stats</h2>
        <table>
          <thead>
            <tr>
              <th>Discipline</th>
              <th>Total Sets</th>
              <th>Average Reps</th>
              <th>Total Weight</th>
            </tr>
          </thead>
          <tbody>
            {stats.map((row) => (
              <tr key={row.discipline}>
                <td>{row.discipline}</td>
                <td>{row._count.id}</td>
                <td>{(row._avg.reps || 0).toFixed(1)}</td>
                <td>{row._sum.weight || 0}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>

      <form className="card filters">
        <label>
          From
          <input type="date" name="from" defaultValue={from} />
        </label>

        <label>
          To
          <input type="date" name="to" defaultValue={to} />
        </label>

        <button>Apply</button>
      </form>

      <Workouts from={from} to={to} />
    </main>
  );
}

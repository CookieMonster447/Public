import { readWorkouts } from "@/repos/workouts";

export async function GET(request) {
  const searchParams = request.nextUrl.searchParams;

  const workouts = await readWorkouts({
    from: searchParams.get("from"),
    to: searchParams.get("to")
  });

  return Response.json(workouts);
}

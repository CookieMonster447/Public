import { readSets } from "@/repos/sets";

export async function GET(request, { params }) {
  const { id } = await params;
  const sets = await readSets(id);

  return Response.json(sets);
}

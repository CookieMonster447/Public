import { deleteSet, updateSet } from "@/repos/sets";

export async function PATCH(request, { params }) {
  try {
    const { id } = await params;
    const body = await request.json();
    const set = await updateSet(id, body);

    return Response.json(set);
  } catch (error) {
    return Response.json(
      { error: error.message },
      { status: 400 }
    );
  }
}

export async function DELETE(request, { params }) {
  try {
    const { id } = await params;

    await deleteSet(id);

    return Response.json({ ok: true });
  } catch (error) {
    return Response.json(
      { error: error.message },
      { status: 400 }
    );
  }
}

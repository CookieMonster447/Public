"use server";

import { revalidatePath } from "next/cache";
import { createSet } from "@/repos/sets";

export async function createSetAction(previousState, formData) {
  try {
    await createSet({
      workoutId: formData.get("workoutId"),
      exercise: formData.get("exercise"),
      reps: formData.get("reps"),
      minutes: formData.get("minutes"),
      weight: formData.get("weight"),
      completedAt: formData.get("completedAt")
    });

    revalidatePath("/");

    return { error: "", ok: true };
  } catch (error) {
    return { error: error.message, ok: false };
  }
}

export const metadata = {
  title: "Workout Log",
  description: "Workout log mock exam solution"
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
